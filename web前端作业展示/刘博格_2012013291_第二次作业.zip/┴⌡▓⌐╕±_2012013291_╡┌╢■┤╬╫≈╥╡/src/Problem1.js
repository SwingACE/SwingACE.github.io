//strength is the set of the relative strength of each country, you can change the number as you wish but 
//not the code of each country like 'C1'
var strength = {A1:0,A2:0,B1:2,B2:0,C1:0,C2:1,D1:0,D2:0,E1:0,E2:0,F1:0,F2:1,G1:0,G2:0,H1:0,H2:0};
//calculate the first round result, wini is the probability of the ith team to get into the final eight
function firstRound (strength,country1,country2){
	if (strength[country1] == 0 && strength[country2] == 0){
		var win1 = 0.5;
		var win2 = 0.5;
	}
	else{
		var win1 = (strength[country1] / (strength[country1]+strength[country2]));
		var win2 = (strength[country2] / (strength[country1]+strength[country2]));
	}
	var firstRoundResult = [country1,country2,win1,win2];
	return firstRoundResult;
}
//using this function to calculate the probability of country1 winning over country2
function calChanceForSomeTeam(strength,country1,country2){
	if (strength[country1] == 0 && strength[country2] == 0){
		return 0.5;
	}
	else{
		var chance = (strength[country1] / (strength[country1]+strength[country2]));
		return chance;
	}
}
//calculate the second round result, wini is the probability of the ith team to get into the final four
function secondRound(strength,firstRoundResultA,firstRoundResultB){
	var win1 = (firstRoundResultA[2]*firstRoundResultB[2]*calChanceForSomeTeam(strength,firstRoundResultA[0],firstRoundResultB[0])+firstRoundResultA[2]*firstRoundResultB[3]*calChanceForSomeTeam(strength,firstRoundResultA[0],firstRoundResultB[1]));
	var win2 = (firstRoundResultA[3]*firstRoundResultB[2]*calChanceForSomeTeam(strength,firstRoundResultA[1],firstRoundResultB[0])+firstRoundResultA[3]*firstRoundResultB[3]*calChanceForSomeTeam(strength,firstRoundResultA[1],firstRoundResultB[1]));
	var win3 = (firstRoundResultB[2]*firstRoundResultA[2]*calChanceForSomeTeam(strength,firstRoundResultB[0],firstRoundResultA[0])+firstRoundResultB[2]*firstRoundResultA[3]*calChanceForSomeTeam(strength,firstRoundResultB[0],firstRoundResultA[1]));
	var win4 = (firstRoundResultB[3]*firstRoundResultA[2]*calChanceForSomeTeam(strength,firstRoundResultB[1],firstRoundResultA[0])+firstRoundResultB[3]*firstRoundResultA[3]*calChanceForSomeTeam(strength,firstRoundResultB[1],firstRoundResultA[1]));
	var secondRoundResult = [firstRoundResultA[0],firstRoundResultA[1],firstRoundResultB[0],firstRoundResultB[1],win1,win2,win3,win4];
	return secondRoundResult;
}
//calculate the third round result, wini is the probability of the ith team to get into the final match
function thirdRound(strength,secondRoundResultA,secondRoundResultB){
	var win1 = (secondRoundResultA[4]*secondRoundResultB[4]*calChanceForSomeTeam(strength,secondRoundResultA[0],secondRoundResultB[0])+secondRoundResultA[4]*secondRoundResultB[5]*calChanceForSomeTeam(strength,secondRoundResultA[0],secondRoundResultB[1])+secondRoundResultA[4]*secondRoundResultB[6]*calChanceForSomeTeam(strength,secondRoundResultA[0],secondRoundResultB[2])+secondRoundResultA[4]*secondRoundResultB[7]*calChanceForSomeTeam(strength,secondRoundResultA[0],secondRoundResultB[3]));
	var win2 = (secondRoundResultA[5]*secondRoundResultB[4]*calChanceForSomeTeam(strength,secondRoundResultA[1],secondRoundResultB[0])+secondRoundResultA[5]*secondRoundResultB[5]*calChanceForSomeTeam(strength,secondRoundResultA[1],secondRoundResultB[1])+secondRoundResultA[5]*secondRoundResultB[6]*calChanceForSomeTeam(strength,secondRoundResultA[1],secondRoundResultB[2])+secondRoundResultA[5]*secondRoundResultB[7]*calChanceForSomeTeam(strength,secondRoundResultA[1],secondRoundResultB[3]));
	var win3 = (secondRoundResultA[6]*secondRoundResultB[4]*calChanceForSomeTeam(strength,secondRoundResultA[2],secondRoundResultB[0])+secondRoundResultA[6]*secondRoundResultB[5]*calChanceForSomeTeam(strength,secondRoundResultA[2],secondRoundResultB[1])+secondRoundResultA[6]*secondRoundResultB[6]*calChanceForSomeTeam(strength,secondRoundResultA[2],secondRoundResultB[2])+secondRoundResultA[6]*secondRoundResultB[7]*calChanceForSomeTeam(strength,secondRoundResultA[2],secondRoundResultB[3]));
	var win4 = (secondRoundResultA[7]*secondRoundResultB[4]*calChanceForSomeTeam(strength,secondRoundResultA[3],secondRoundResultB[0])+secondRoundResultA[7]*secondRoundResultB[5]*calChanceForSomeTeam(strength,secondRoundResultA[3],secondRoundResultB[1])+secondRoundResultA[7]*secondRoundResultB[6]*calChanceForSomeTeam(strength,secondRoundResultA[3],secondRoundResultB[2])+secondRoundResultA[7]*secondRoundResultB[7]*calChanceForSomeTeam(strength,secondRoundResultA[3],secondRoundResultB[3]));
	var win5 = (secondRoundResultB[4]*secondRoundResultA[4]*calChanceForSomeTeam(strength,secondRoundResultB[0],secondRoundResultA[0])+secondRoundResultB[4]*secondRoundResultA[5]*calChanceForSomeTeam(strength,secondRoundResultB[0],secondRoundResultA[1])+secondRoundResultB[4]*secondRoundResultA[6]*calChanceForSomeTeam(strength,secondRoundResultB[0],secondRoundResultA[2])+secondRoundResultB[4]*secondRoundResultA[7]*calChanceForSomeTeam(strength,secondRoundResultB[0],secondRoundResultA[3]));
	var win6 = (secondRoundResultB[5]*secondRoundResultA[4]*calChanceForSomeTeam(strength,secondRoundResultB[1],secondRoundResultA[0])+secondRoundResultB[5]*secondRoundResultA[5]*calChanceForSomeTeam(strength,secondRoundResultB[1],secondRoundResultA[1])+secondRoundResultB[5]*secondRoundResultA[6]*calChanceForSomeTeam(strength,secondRoundResultB[1],secondRoundResultA[2])+secondRoundResultB[5]*secondRoundResultA[7]*calChanceForSomeTeam(strength,secondRoundResultB[1],secondRoundResultA[3]));
	var win7 = (secondRoundResultB[6]*secondRoundResultA[4]*calChanceForSomeTeam(strength,secondRoundResultB[2],secondRoundResultA[0])+secondRoundResultB[6]*secondRoundResultA[5]*calChanceForSomeTeam(strength,secondRoundResultB[2],secondRoundResultA[1])+secondRoundResultB[6]*secondRoundResultA[6]*calChanceForSomeTeam(strength,secondRoundResultB[2],secondRoundResultA[2])+secondRoundResultB[6]*secondRoundResultA[7]*calChanceForSomeTeam(strength,secondRoundResultB[2],secondRoundResultA[3]));
	var win8 = (secondRoundResultB[7]*secondRoundResultA[4]*calChanceForSomeTeam(strength,secondRoundResultB[3],secondRoundResultA[0])+secondRoundResultB[7]*secondRoundResultA[5]*calChanceForSomeTeam(strength,secondRoundResultB[3],secondRoundResultA[1])+secondRoundResultB[7]*secondRoundResultA[6]*calChanceForSomeTeam(strength,secondRoundResultB[3],secondRoundResultA[2])+secondRoundResultB[7]*secondRoundResultA[7]*calChanceForSomeTeam(strength,secondRoundResultB[3],secondRoundResultA[3]));
	var thirdRoundResult = [secondRoundResultA[0],secondRoundResultA[1],secondRoundResultA[2],secondRoundResultA[3],secondRoundResultB[0],secondRoundResultB[1],secondRoundResultB[2],secondRoundResultB[3],win1,win2,win3,win4,win5,win6,win7,win8];
	return thirdRoundResult;
}
//forecast the probability of a given country to win the world cup
function forecast(strength,country){
	var firstRoundResult1 = firstRound(strength,'A1','B2');
	var firstRoundResult2 = firstRound(strength,'C1','D2');
	var firstRoundResult3 = firstRound(strength,'E1','F2');
	var firstRoundResult4 = firstRound(strength,'G1','H2');
	var firstRoundResult5 = firstRound(strength,'B1','A2');
	var firstRoundResult6 = firstRound(strength,'D1','C2');
	var firstRoundResult7 = firstRound(strength,'F1','E2');
	var firstRoundResult8 = firstRound(strength,'H1','G2');
	var secondRoundResult1 = secondRound(strength,firstRoundResult1,firstRoundResult2);
	var secondRoundResult2 = secondRound(strength,firstRoundResult3,firstRoundResult4);
	var secondRoundResult3 = secondRound(strength,firstRoundResult5,firstRoundResult6);
	var secondRoundResult4 = secondRound(strength,firstRoundResult7,firstRoundResult8);
	var thirdRoundResult1 = thirdRound(strength,secondRoundResult1,secondRoundResult2);
	var thirdRoundResult2 = thirdRound(strength,secondRoundResult3,secondRoundResult4);
	//whichResult represents which side the country is on, left of right
	var whichResult = 0;
	//chance is the probability that the given country can get into the final match
	var chance = 0;
	for (var i = 0; i < 8; i++){
		if (thirdRoundResult1[i] == country){
			chance = thirdRoundResult1[i+8];
			whichResult = 1;
			break;
		}
	}
	//win is the probability that the given country can finally win the world cup
	var win = 0;
	if (whichResult == 1){
		for (var j = 0; j < 8; j++){
			win += thirdRoundResult2[j+8]*calChanceForSomeTeam(strength,country,thirdRoundResult2[j]);
		}
		win *= chance;
	}
	else{
		for (var i = 0; i < 8; i++){
			if (thirdRoundResult2[i] == country){
				chance = thirdRoundResult2[i+8];
				whichResult = 2;
				break;
			}
		}
		for (var j = 0; j < 8; j++){
			win += thirdRoundResult1[j+8]*calChanceForSomeTeam(strength,country,thirdRoundResult1[j]);
		}
		win *= chance;			
	}
	alert(win);
	return win;
}
//if you want to forecast a country's probability to win the world cup,
//just input the corresponding code of the country, like 'B1'
forecast (strength,'B1');