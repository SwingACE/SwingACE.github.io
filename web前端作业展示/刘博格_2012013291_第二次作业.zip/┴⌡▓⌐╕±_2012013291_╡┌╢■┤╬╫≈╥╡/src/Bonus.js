function diff (students1,students2){
	var result = new Array();
	for (var n in students2){
		var repeat = false;
		for (var m in students1){
			if (students1[m].name == students2[n].name){
				repeat = true;
				break;
			}
		}
		if (!repeat){
			result.push(students2[n]);
		}
	}
	return result;
}
//the following is my testing code, ignore it
function student(name,age,hometown){
	this.name = name;
	this.age = age;
	this.hometown = hometown;
}
var students1 = new Array();
var student1 = new student('lbg',20,'anhui');
students1.push(student1);
var student2 = new student('nzt',20,'jiangxi');
students1.push(student2);
var student3 = new student('zjy',21,'hebei');
students1.push(student3);
var student4 = new student('lbg',19,'beijing');
students1.push(student4);
var student5 = new student('lbg',20,'beijing');
students1.push(student5);
var student6 = new student('llt',20,'anhui');
students1.push(student6);
var student7 = new student('llt',20,'anhui');
students1.push(student7);
var students2 = new Array();
var student1 = new student('lbg',20,'anhui');
students2.push(student1);
var student2 = new student('nzt',20,'jiangxi');
students2.push(student2);
var student3 = new student('zjy',21,'hebei');
students2.push(student3);
var student4 = new student('sss',19,'beijing');
students2.push(student4);
var student5 = new student('lbg',20,'beijing');
students2.push(student5);
var student6 = new student('llt',20,'anhui');
students2.push(student6);
var student7 = new student('kkk',20,'anhui');
students2.push(student7);
var searchResult = diff(students1,students2);
alert(searchResult.length);
alert(searchResult[0].name);
alert(searchResult[0].age);
alert(searchResult[0].hometown);