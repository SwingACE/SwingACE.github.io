function search(students,targetAtrribute){
	var result = new Array();
	var isFound = false;
	//determine if targetAtrribute is age attribute
	if (typeof(targetAtrribute) == 'number'){
		for (var m in students){
			if(students[m].age == targetAtrribute){
				result.push(students[m]);
				isFound = true;
			}
		}
		if (isFound){
			return result;
		}
		else{
			return false;
		}
	}
	//determine if targetAtrribute is name attribute
	else if (typeof(targetAtrribute) == 'string'){
		for (var m in students){
			if(students[m].name == targetAtrribute){
				result.push(students[m]);
				isFound = true;
			}
		}
		if (isFound){
			return result[0];
		}
		else{
			return false;
		}
	}
	//targetAtrribute is an object
	else{
		//match name attribute first, then age, then hometown 
		//of course the premise is that the targetAtrribute contains these attributes
		var nameMatch = new Array();
		var ageMatch = new Array();
		var hometownMatch = new Array();
		//alreadyMatched represents in which attribute the function last matches
		var alreadyMatched = 0;
		//determine whether targetAtrribute contains name attribute
		if (typeof(targetAtrribute.name) != 'undefined'){
			//matches name attribute
			alreadyMatched = 1;
			for (var m in students){
				if (students[m].name == targetAtrribute.name){
					nameMatch.push(students[m]);
				}
			}
			if (nameMatch.length == 0){
				return false;
			}
		}
		//determine whether targetAtrribute contains age attribute
		if (typeof(targetAtrribute.age) != 'undefined'){
			//matches age attribute
			alreadyMatched = 2;
			if(nameMatch.length != 0){
				for (var m in nameMatch){
					if (nameMatch[m].age == targetAtrribute.age){
						ageMatch.push(nameMatch[m]);
					}
				}
				if (ageMatch.length == 0){
					return false;
				}
			}
			else{
				for (var m in students){
					if (students[m].age == targetAtrribute.age){
						ageMatch.push(students[m]);
					}
				}
				if (ageMatch.length == 0){
					return false;
				}
			}
		}
		//determine whether targetAtrribute contains hometown attribute
		if (typeof(targetAtrribute.hometown) != 'undefined'){
			//matches hometown attribute
			alreadyMatched = 3;
			if (ageMatch.length != 0){
				for (var m in ageMatch){
					if (ageMatch[m].hometown == targetAtrribute.hometown){
						hometownMatch.push(ageMatch[m]);
					}
				}
				if (hometownMatch.length == 0){
					return false;
				}
			}
			else if (nameMatch.length != 0){
				for (var m in nameMatch){
					if (nameMatch[m].hometown == targetAtrribute.hometown){
						hometownMatch.push(nameMatch[m]);
					}
				}
				if (hometownMatch.length == 0){
					return false;
				}
			}
			else{
				for (var m in students){
					if (students[m].hometown == targetAtrribute.hometown){
						hometownMatch.push(students[m]);
					}
				}
				if (hometownMatch.length == 0){
					return false;
				}
			}
		}
		//return the result according to the match stag 
		if (alreadyMatched == 0){
			return false;
		}
		if (alreadyMatched == 1){
			return nameMatch;
		}
		if (alreadyMatched == 2){
			return ageMatch;
		}
		if (alreadyMatched == 3){
			return hometownMatch;
		}
	}
}
//the following is my testing code, ignore it
function student(name,age,hometown){
	this.name = name;
	this.age = age;
	this.hometown = hometown;
}
var students = new Array();
var student1 = new student('lbg',20,'anhui');
students.push(student1);
var student2 = new student('nzt',20,'jiangxi');
students.push(student2);
var student3 = new student('zjy',21,'hebei');
students.push(student3);
var student4 = new student('lbg',19,'beijing');
students.push(student4);
var student5 = new student('lbg',20,'beijing');
students.push(student5);
var student6 = new student('llt',20,'anhui');
students.push(student6);
var student7 = new student('llt',20,'anhui');
students.push(student7);
var targetAtrribute = {name:'nzt',hometown:'jiangxi'};
var searchResult = search(students,targetAtrribute);
alert(searchResult);
alert(searchResult.length);
alert(searchResult[0].name);
alert(searchResult[0].age);
alert(searchResult[0].hometown);